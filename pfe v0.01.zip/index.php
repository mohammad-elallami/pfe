
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecom pfe</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Ecom pfe</h1>
    </header>
    <nav>
        <a href="#">Home</a>
        <a href="#">Category</a>
        <a href="#">About</a>
        <a href="#">Contact</a>
		<a href="#">login</a>
        <a href="#">register</a>
    </nav>
    <section id="products">
    
    </section>
    <footer>
        &copy; 2024 Ecom pfe. All rights reserved.
    </footer>

</body>
</html>



